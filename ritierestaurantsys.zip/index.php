<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RESTAURANT</title>
    <link rel="stylesheet" href="http://localhost/restaurantSystem2/Assets/css/ritieTheme.css">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><i class="fa-solid fa-utensils"></i> Restaurant</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="card shadow-lg border-1 border-primary rounded-lg mt-5">
                    <div class="card-header">
                        <h3 class="text-center font-weight-light my-4">Iniciar sesión</h3>
                    </div>
                    <div class="text-center pt-2">
                        <?php include_once "../Config/App/Conn.php"?>  
                        <?php include_once "../Controllers/Login.php"?>  
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                        <div class="form-group pb-3">
                            <input id="user" type="text" class="form-control" name="user" placeholder="Usuario" autocomplete="off">
                        </div>
                        <div class="form-group">
                            <input id="password" type="password" class="form-control" name="password" placeholder="Contraseña">
                        </div>
                        <div class="form-group d-flex align-items-center justify-content-between mt-3 mb-0">
                            <input class="btn btn-primary" type="submit" name="loginBtn" value="Iniciar sesión">
                        </div>
                    </div>
                </form>
            </div>
                </div> 
            </div>
        </div>
    </div>
    <!-- font awesome -->
    <script src="http://localhost/restaurantSystem2/Assets/js/all.min.js" integrity="sha512-8pHNiqTlsrRjVD4A/3va++W1sMbUHwWxxRPWNyVlql3T+Hgfd81Qc6FC5WMXDC+tSauxxzp1tgiAvSKFu1qIlA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> 
    <!-- jquery -->
    <script src="http://localhost/restaurantSystem2/Assets/js/jquery-3.6.1.min.js"></script>
    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <!-- ajax -->
    <script src="http://localhost/restaurantSystem2/Assets/js/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="http://localhost/restaurantSystem2/Assets/js/jquery.dataTables.min.js"></script>
    <script src="http://localhost/restaurantSystem2/Assets/js/dataTables.bootstrap5.min.js"></script>

    <script src="http://localhost/restaurantSystem2/Assets/js/jquery-ui/jquery-ui.min.js"></script>
    <script src="http://localhost/restaurantSystem2/Assets/js/jquery-ui/jquery-ui.js"></script>
    
    <script src="http://localhost/restaurantSystem2/Assets/js/app.js"></script>
    
    <script src="http://localhost/restaurantSystem2/Assets/js/sweetalert2.all.min.js"></script>
</body>
</html>