  
    <footer>
        <div class="social-icons-container">
            <a href="" class="social-icon"></a>
            <a href="" class="social-icon"></a>
            <a href="" class="social-icon"></a>
            <a href="" class="social-icon"></a>
        </div>
        <ul class="footer-menu-container">
            <li class="menu-item"></li>
        </ul>
    </footer>
    <!-- font awesome -->
    <script src="http://localhost/restaurantSystem2/Assets/js/all.min.js" integrity="sha512-8pHNiqTlsrRjVD4A/3va++W1sMbUHwWxxRPWNyVlql3T+Hgfd81Qc6FC5WMXDC+tSauxxzp1tgiAvSKFu1qIlA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> 
    <!-- jquery -->
    <script src="http://localhost/restaurantSystem2/Assets/js/jquery-3.6.1.min.js"></script>
    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <!-- ajax -->
    <script src="http://localhost/restaurantSystem2/Assets/js/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="http://localhost/restaurantSystem2/Assets/js/jquery.dataTables.min.js"></script>
    <script src="http://localhost/restaurantSystem2/Assets/js/dataTables.bootstrap5.min.js"></script>

    <script src="http://localhost/restaurantSystem2/Assets/js/jquery-ui/jquery-ui.min.js"></script>
    <script src="http://localhost/restaurantSystem2/Assets/js/jquery-ui/jquery-ui.js"></script>
    
    <script src="http://localhost/restaurantSystem2/Assets/js/app.js"></script>
    
    <script src="http://localhost/restaurantSystem2/Assets/js/sweetalert2.all.min.js"></script>
    <script src="http://localhost/restaurantSystem2/Assets/js/functions.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/js-cookie@3.0.1/dist/js.cookie.min.js"></script>
</body>
</html>