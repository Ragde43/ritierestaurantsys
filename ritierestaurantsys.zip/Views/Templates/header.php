<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant System</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="http://localhost/restaurantSystem2/Assets/css/ritieTheme.css">
    <link rel="stylesheet" href="http://localhost/restaurantSystem2/Assets/css/styles.css">
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container-fluid text-white">
        <a class="navbar-brand" href="http://localhost/restaurantSystem2/index.php"><i class="fa-solid fa-utensils"></i> Restaurant</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse pb-1" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item ">
              <a class="nav-link" href="http://localhost/restaurantSystem2/Views/Orders/index.php" role="button" aria-expanded="false" ><i class="fa-solid fa-note-sticky"></i> ORDENES</a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" href="#" role="button" aria-expanded="false" ><i class="fa-solid fa-book"></i> VENTAS</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle disable-link" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-boxes-stacked"></i> PRODUCTOS</a>
              <ul class="dropdown-menu" >
                <li><a class="dropdown-item" href="http://localhost/restaurantSystem2/Views/Products/index.php">Inventario</a></li>
                <!-- <li><a class="dropdown-item" href="http://localhost/restaurantSystem2/Views/ProductTypes/index.php">Tipos de producto</a></li> -->
              </ul>
            </li>
            <li class="nav-item">
              <a href="http://localhost/restaurantSystem2/Views/Tables/index.php" class="nav-link"><i class="fa-solid fa-bowl-food"></i>MESAS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="http://localhost/restaurantSystem2/Views/User/index.php" role="button" aria-expanded="false"><i class="fa-solid fa-user"></i> USUARIO</a>
            </li>
              </ul>
            <form class="d-flex">
              <a class="nav-link right-icons me-3" style="" href="http://localhost/restaurantSystem2/Views/Configuration/index.php" id="logout" role="button" aria-expanded="false"><i class="fa-solid fa-gear"></i></a>
              <a class="nav-link right-icons me-3" href="http://localhost/restaurantSystem2/Controllers/Logout.php" id="logout" role="button" aria-expanded="false"><i class="fa-solid fa-right-from-bracket"></i></a>
          </form>
        </div>
      </div>
    </nav>
</head>
<body>
