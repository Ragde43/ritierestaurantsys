<?php include "../../Config/App/LoginControl.php"?>
<?php include "../Templates/header.php"?>
<?php include "../../Config/App/Conn.php"?>  
<div class="p-3 pb-0">
    <ol class="breadcrumb justify-content-center">
        <li class="breadcrumb-item active">MESAS</li>
    </ol>
</div>
<div class="text-center">
    <button class="btn btn-info" onclick="addTable()">Agregar mesa</button>
</div>
<div class="p-3 row badges-container">
    <div class="col text-center badge-col">
        <span class="badge bg-warning"><h3 class="text-white"><strong>CON COMENSAL</strong></h3></span>
    </div>
    <div class="col text-center">
        <span class="badge bg-light"><h3 class="text-black"><strong>SIN COMENSAL</strong></h3></span>
    </div>
</div>

<div class="p-3 row">
        <div class="card-body" id="table_status">
            <div class="p-3 row wrapper">
                <?php
                    $sql = "SELECT * FROM dinersTable";
                    $result = mysqli_query($conn, $sql);
                    $resultCheck = mysqli_num_rows($result);
                    if ($resultCheck > 0) {
                        while($row = mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $active = $row['activeTable'];
                            if($active==1){
                                echo   '<div class="col"> 
                                            <button type="button" id="table'.$id.'" class="btn btn-warning" style="width: 100%; height: 5rem;" onclick="orderForm('.$id.','.$active.')">
                                                <h1 class="text-white"><strong>'.$id.'</strong></h1>
                                            </button> 
                                        </div>';
                            }else {
                                echo    '<div class="col"> 
                                            <button type="button" id="table'.$id.'" class="btn btn-light" style="width: 100%; height: 5rem;" onclick="orderForm('.$id.','.$active.')">
                                                <h1 class="text-black"><strong>'.$id.'</strong></h1>
                                            </button>
                                        </div>';
                            }
                        }
                    }
                ?>
            </div>
        </div>
    </div>
</div>    

<div class="text-weight">
    <div id="order" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalTitle">Orden de mesa</h5>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col text-center" style="width: 30%">
                            <h1><i class="fa-regular fa-user"></i></h1>
                            <h3>Cliente</h3>
                            <select class="form-select" name="" id="clientSelect">
                            
                            </select>
                            <div id="orderResume" class="mt-3 text-align-left">
                                <strong>Bebida</strong><br>
                                <label id="lblDrink" for=""></label><br>
                                <strong>Entrada</strong><br>
                                <label id="lblEntry" for=""></label><br>
                                <strong>Plato principal</strong><br>
                                <label id="lblMainDish" for=""></label><br>
                                <strong>Postre</strong><br>
                                <label id="lblDessert" for=""></label><br>
                            </div>
                            <!-- <div class="mt-3">
                                <button class="btn btn-info" onclick = "addToOrder();">Agregar a la orden</button>
                            </div> -->
                        </div>
                        <form class="col-8" method="post" id="tableActiveForm">
                            <input type="hidden" id="id" name="id">
                            <div class="form-group text-center">
                                <?php
                                    $sql = "SELECT * FROM productTypes";
                                    $result = mysqli_query($conn, $sql);
                                    $resultCheck = mysqli_num_rows($result);
                                    if ($resultCheck > 0) {
                                        while($row = mysqli_fetch_assoc($result)){
                                            $id = $row['id'];
                                            $typeName = $row['typeName'];
                                            echo '<button type="button" id="type'.$id.'" class="btn btn-info me-3 pt-1" onclick="setTypeView('.$id.')">'.$typeName.'</button>';
                                        }
                                    }
                                ?>
                            </div>
                            <div id="" class="pt-2 text-center">
                                <div class=" pb-0">
                                    <ol class="titlesContainer breadcrumb justify-content-center">
                                        <li id="typeBreadcrumb" class="breadcrumb-item active"></li>
                                    </ol>
                                </div>
                                <div class="row productSelectorContainer">
                                    <div class="col-9">
                                        <select name="" id="productSelector" class="form-select">
                                        </select>
                                    </div>
                                    <div class="col input-group qtyInput">
                                        <input type="button" value="-" class="button-minus btn btn-success me-1" data-field="quantity">
                                        <input id="qtyInput" type="number" step="1" max="" value="1" name="quantity" class="text-center  quantity-field" style="width: 2rem; border: 0;">
                                        <input type="button" value="+" class="button-plus btn btn-success ms-1" data-field="quantity">
                                    </div>
                                </div>  
                                <div class="pt-2">
                                    <div class="titlesContainer">
                                        COMENTARIOS
                                    </div>
                                    <div class="form-group pt-2">
                                        <textarea name="" id="comentsText" class="form-control" style="height: 6rem; resize: none;"></textarea>
                                    </div>
                                </div> 
                            </div>
    
                            <div class="pb-2 buttonContainer" style="position: absolute; bottom: 0; width: 64%;">
                                <div class="form-group text-center"> 
                                    <button id="modalActionBtn" class="btn btn-success me-3 pt-1" type="button" onclick="addToProvitionalTable(event);">Agregar orden</button>
                                    <button class="btn btn-danger me-3 pt-1" type="button" data-bs-dismiss="modal">Cerrar</button>
                                    <button class="btn btn-secondary me-3 pt-1" type="button" onclick="addClient(event)">Agregar cliente</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="numOfClients" class="modalClientsNum modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog text-center" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="myModalTitleNumOfClients">Orden de mesa</h2>
            </div>
            <div class="modal-body">
                <form method="post" id="numOfClientsForm">
                    <label for=""><h2>Número de clientes</h2></label>
                    <input name="tableId" id="tableId" type="hidden">
                    <input name="tableId2" id="tableId2" type="hidden">
                    <div class="col-lg-4 col-lg-offset-4" style="margin: 0 auto;">
                        <div class="input-group">
                            <input id="numOfClientsInput" name="numOfClientsInput" type="number" class="form-control text-center" style="width: 40%; font-size: 22pt"min="1" value="1">
                        </div>
                    </div>
                    <button id="addTableBtn" type="submit" class="btn btn-success mt-3">
                        <h2>Agregar mesa</h2>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include "../Templates/footer.php"?>