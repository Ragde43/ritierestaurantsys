<?php include "../../Config/App/LoginControl.php"?>
<?php include "../Templates/header.php"?>
<div class="p-3 pb-0">
    <!-- <ol class="breadcrumb justify-content-center">
        <li class="breadcrumb-item active">USUARIO</li>
    </ol> -->
</div>
<div class="container">
    <div class="row">
        <div class="justify-content-center col-sm pt-5 me-2 text-center ">
            <div class="row pb-3">
                <h1 class="text-ritie mb-0" id="welcomeMessage"><strong>¡Bienvenido, <?php echo $_SESSION["userName"]?>!</strong></h1>
            </div>
            <img class="pt-4 profileImg" src="http://localhost/restaurantSystem2/img/waiter2.png" alt="">
        </div>
        <div class="justify-content-center col-sm ms-2 text-center">
            <div class="row">
                <div class="pb-1">
                    <img src="http://localhost/restaurantSystem2/img/ritieDots.svg" height="100" alt="">
                </div>
                <div class="pt-5">
                    <h1 id="date" class="text-ritie mb-0"></h1>
                </div>
            </div>
            <div class="row p-5 pt-0 pb-0 justify-content-center d-flex align-items-center" style="height:100%">
                <button onclick="getStarted();" type="button" class="btn btn-primary btn-lg" style="height: 45%"><h1 class="text-white"><strong>EMPEZAR</strong></h1></button>
            </div>
        </div>
    </div>
</div>
<script src="http://localhost/restaurantSystem2/Assets/js/showDate.js"></script>
<?php include "../Templates/footer.php"?>