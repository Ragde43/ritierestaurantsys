<?php include "../../Config/App/LoginControl.php"?>
<?php include "../Templates/header.php"?>
<?php include "../../Config/App/Conn.php"?>  
<div class="p-3 pb-0">
    <ol class="breadcrumb justify-content-center">
        <li class="breadcrumb-item active">ORDENES</li>
    </ol>
</div>
<div class="p-3 row badges-container">
    <div class="col text-center badge-col">
        <span class="badge bg-warning"><h3 class="text-white"><strong>ORDENES ACTIVAS</strong></h3></span>
    </div>
</div>

<div class="p-3 row">
        <div class="card-body" id="table_status">
            <div class="p-3 row wrapper">
                <?php
                    $sql = "SELECT * FROM dinersTable";
                    $result = mysqli_query($conn, $sql);
                    $resultCheck = mysqli_num_rows($result);
                    if ($resultCheck > 0) {
                        while($row = mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $active = $row['activeTable'];
                            if($active==1){
                                echo   '<div class="col"> 
                                            <button type="button" id="table'.$id.'" class="btn btn-warning" style="width: 100%; height: 5rem;" onclick="orderFormCashierView('.$id.')">
                                                <h1 class="text-white"><strong>'.$id.'</strong></h1>
                                            </button> 
                                        </div>';
                            }
                        }
                    }
                ?>
            </div>
        </div>
    </div>
</div>    

<div class="text-weight">
    <div id="order" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="orderModalTitle">Orden de mesa</h5>
                </div>
                <div class="modal-body">
                        <div id="clientOrdersView" class="row">
                            
                        </div>
                </div>
                <div class="text-center pb-3" style="width: 100%;">
                    <button class="btn btn-info" onclick="payAccount()">COBRAR CUENTA</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="numOfClients" class="modalClientsNum modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog text-center" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="myModalTitleNumOfClients">Orden de mesa</h2>
            </div>
            <div class="modal-body">
                <form method="post" id="numOfClientsForm">
                    <label for=""><h2>Número de clientes</h2></label>
                    <input name="tableId" id="tableId" type="hidden">
                    <input name="tableId2" id="tableId2" type="hidden">
                    <div class="col-lg-4 col-lg-offset-4" style="margin: 0 auto;">
                        <div class="input-group">
                            <input id="numOfClientsInput" name="numOfClientsInput" type="number" class="form-control text-center" style="width: 40%; font-size: 22pt"min="1" value="1">
                        </div>
                    </div>
                    <button id="addTableBtn" type="submit" class="btn btn-success mt-3">
                        <h2>Agregar mesa</h2>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include "../Templates/footer.php"?>