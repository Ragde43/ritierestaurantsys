<?php include "../../Config/App/LoginControl.php"?>
<?php include "../Templates/header.php"?>
<?php include "../../Config/App/Conn.php"?>  
<div class="p-3 pb-0">
    <ol class="breadcrumb justify-content-center">
        <li class="breadcrumb-item active">INVENTARIO</li>
    </ol>
</div>
<div class="p-3 pt-0">
    <button class="btn btn-primary" type="button" onclick="addProductForm()"><i class="fa-solid fa-plus"></i> Agregar producto</button>
</div>
<div class="p-3 pt-0">
    <div class="row-md-4">
        <div class="card">
            <form method="POST">
                <div class="form-group">
                    <input  href="" type="search" id="searchClient" name="clientKey" class="form-control"
                    placeholder="Buscar producto"  autocomplete="off" autofocus onkeydown="return event.key != 'Enter';">    
                </div>
            </form>
        </div>
    </div>
</div>
<div class="p-3 pt-0">
    <div class="table-responsive">
        <table  class="table table-dark table-curved" id="tableProducts">
            <thead>
                <tr>
                    <th style="width:30%">Descripción</th>
                    <th style="width:10%">Precio</th>
                    <th style="width:10%">Stock</th>
                    <th style="width:10%">Tipo</th>
                    <th class="text-center" style="width:10%">Editar</th>
                </tr>
            </thead>
        </table> 
    </div>
</div>
<div id="newProduct" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalTitle">Agregar producto</h5>
            </div>
            <div class="modal-body">
                <form method="post" id="productForm">
                    <input type="hidden" id="id" name="id">
                    <div class="form-group">
                        <label for="productName">Descripción</label>
                        <input id="productName" class="form-control" type="text" name="productName" autocomplete="off" placeholder="Nombre del producto">
                    </div>
                    <div id="priceDiv" class="form-group">
                        <label for="price">Precio</label>
                        <input id="price" class="form-control" type="number" name="price" autocomplete="off" placeholder="0">
                    </div>
                    <div id="stockDiv" class="form-group">
                        <label for="stock">Stock</label>
                        <input id="stock" class="form-control" type="number" name="stock" autocomplete="off" placeholder="0">
                    </div>
                    <div class="form-group">
                        <label for="productType">Tipo</label>
                        <select id="productTypeSelect" class="form-control" name="productType" style="-webkit-appearance: listbox;">

                        </select>
                    </div>
                    <div class="pt-3">
                        <div class="row">
                            <div class="col text-center">
                                <button id="modalActionBtn" class="btn btn-primary" type="button" onclick="addProduct(event);">Agregar</button>
                            </div>
                            <div class="col text-center">
                                <button class="btn btn-danger" type="button" data-bs-dismiss="modal">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include "../Templates/footer.php"?>
