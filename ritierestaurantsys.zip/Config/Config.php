<?php

const base_url = "http://localhost/restaurantSystem2/";
const host = "localhost";
const user = "root";
const pass = "jimmywessMpeavey1!";
const db = "meserosbd";
const charset = "charset=utf8";
?>