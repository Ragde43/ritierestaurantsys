<?php

class Query extends Conn{
    private $pdo, $conn, $sql,$dataset;
    public function __construct() {
        $this->pdo = new Conn();
        $this->conn = $this->pdo->connect();
    }

    public function select(string $sql){
        $this->sql = $sql;
        $res = $this->conn->prepare($this->sql);
        $res->execute();
        $data = $res->fetch(PDO::FETCH_ASSOC);
        return $data;
    }

    public function selectAll(string $sql){
        $this->sql = $sql;
        $res = $this->conn->prepare($this->sql);
        $res->execute();
        $data = $res->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }

    public function saveDataset(string $sql, array $dataset){
        $this->sql = $sql;
        $this->dataset = $dataset;
        $insert = $this->conn->prepare($this->sql);
        $data = $insert->execute($this->dataset);
        if ($data) {
            $res = 1;
        }else {
            $res = 0;
        }
        return $res;
    }
}

?>