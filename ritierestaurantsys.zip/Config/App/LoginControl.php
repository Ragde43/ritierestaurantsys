<?php 
    session_start(); 
    if(empty($_SESSION["id"])){
        header("location: http://localhost/restaurantSystem2/Views/index.php");
    }
?>