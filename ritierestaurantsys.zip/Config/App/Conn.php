<?php

    $conn = new mysqli("localhost","root","jimmywessMpeavey1!","meserosbd");
    $conn->set_charset("utf8")
?>