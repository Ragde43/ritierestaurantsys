<?php include "../Config/App/Conn.php"?>  
<?php
    $string="";
    if ($_COOKIE) {
        $clientNum = $_COOKIE['clientNum'];
        $tableId = $_COOKIE['tableId'];
        $qty="";
        $productName="";
        $productType="";
        $sql = "SELECT * FROM provitionalOrderTable WHERE clientNum = $clientNum AND tableId = $tableId AND activeOrder = TRUE";
        $result = mysqli_query($conn, $sql);
        $resultCheck = mysqli_num_rows($result);
        if ($resultCheck > 0) {
            foreach ($result as $provitionalOrder):
               $productName .= $provitionalOrder['productName'].',';
               $productType .= $provitionalOrder['productType'].',';
               $qty .= $provitionalOrder['quantity'].',';
            endforeach;
           $string = $qty.$productName.$productType;
           $dataQty = explode(',',$qty);
           array_pop($dataQty);
           $dataProdName = explode(',',$productName);
           array_pop($dataProdName);
           $dataProdType = explode(',',$productType);
           array_pop($dataProdType);
           $data = [
                'qty' => $dataQty,
                'productName' => $dataProdName,
                'productType' => $dataProdType
           ];
           echo json_encode($data);
        }
    }
?>
