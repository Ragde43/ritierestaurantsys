<?php include "../Config/App/Conn.php"?>  
<?php
    $string="";
    $data = "";
    if ($_COOKIE) {
        $tableId = $_COOKIE['tableId'];
        $qty="";
        $productName="";
        $productType="";
        $clientNum="";
        $sql = "SELECT * FROM provitionalOrderTable WHERE tableId = $tableId AND activeOrder = TRUE";
        $result = mysqli_query($conn, $sql);
        $resultCheck = mysqli_num_rows($result);
        if ($resultCheck > 0) {
            foreach ($result as $provitionalOrder):
               $productName .= $provitionalOrder['productName'].',';
               $productType .= $provitionalOrder['productType'].',';
               $qty .= $provitionalOrder['quantity'].',';
               $clientNum .= $provitionalOrder['clientNum'].',';
            endforeach;
           $string = $qty.$productName.$productType;
           $dataQty = explode(',',$qty);
           array_pop($dataQty);
           $dataProdName = explode(',',$productName);
           array_pop($dataProdName);
           $dataProdType = explode(',',$productType);
           array_pop($dataProdType);
           $dataClientNum = explode(',',$clientNum);
           array_pop($dataClientNum);
           array_unique($dataClientNum);
           $data = [
                'qty' => $dataQty,
                'productName' => $dataProdName,
                'productType' => $dataProdType,
                'clientNum' => $dataClientNum
           ];
        }
        echo json_encode($data);
    }
?>
