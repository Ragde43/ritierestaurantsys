<?php include "../Config/App/Conn.php";

    $jsonString = "";   
        $sql = "SELECT * FROM productTypes";
        $result = mysqli_query($conn,$sql) or die (mysqli_error($conn));
        foreach ($result as $productTypes):
            $jsonString .= '<option value="'.$productTypes['id'].'">'.$productTypes['typeName'].'</option> ';
        endforeach;
        echo json_encode($jsonString);

?>
