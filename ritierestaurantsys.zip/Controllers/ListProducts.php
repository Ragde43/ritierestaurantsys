<?php

function listProducts(){
    $sql = "SELECT products.id,productKey,productName,productCost,price,stock,productTypes.typeName FROM products INNER JOIN productTypes WHERE products.productType = productTypes.id";
    $data = $this->selectAll($sql);
    $data = $this->model->getAllProducts();       
    for ($i=0; $i<count($data); $i++) { 
        $id = (int)$data[$i]['id'];
        $data[$i]['actions'] = '<div class="text-center">
        <button class="btn btn-primary" type="button" onclick="editProduct('.$id.');"><i class="fa-solid fa-pen-to-square"></i></button>
        <button class="btn btn-danger" type="button" onclick="deleteProduct('.$id.');"><i class="fa-solid fa-trash"></i></button>
        <div/>';
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    die();
}

?>