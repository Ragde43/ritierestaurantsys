<?php include "../Config/App/Conn.php";  


    $sql = "CALL spAddDinersTable(1)";
    $result = mysqli_query($conn, $sql);
    echo json_encode($result);
   
?>