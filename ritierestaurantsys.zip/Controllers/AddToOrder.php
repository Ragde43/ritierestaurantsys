<?php include "../Config/App/Conn.php";  

    if($_COOKIE){
        $id = $_COOKIE['tableId'];
        $numOfClients = $_COOKIE['numOfClientsInput'];
        if ($numOfClients != "" && $id != "") {
            $sql = "CALL spUpdateTableClients($id,$numOfClients)";
            $result = mysqli_query($conn, $sql);
            echo json_encode($result);
        }else{
            echo json_encode('fill all data');
        }
    }
   
?>