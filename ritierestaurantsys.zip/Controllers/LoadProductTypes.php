<?php include "../Config/App/Conn.php";

    $jsonString = "";   
    if($_COOKIE){
        $id = $_COOKIE['typeId'];
        $sql = "SELECT * FROM products WHERE productTypeId = $id";
        $result = mysqli_query($conn,$sql) or die (mysqli_error($conn));
        foreach ($result as $productName):
                $jsonString .= '<option value="'.$productName['productTypeId'].'">'.$productName['productName'].'</option> ';
        endforeach;
        echo json_encode($jsonString);
    }

?>
