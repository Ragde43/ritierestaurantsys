<?
public function validateLogin(){
    if (!empty($_POST["loginBtn"])) {
        echo 'jai';
    }
}



?>