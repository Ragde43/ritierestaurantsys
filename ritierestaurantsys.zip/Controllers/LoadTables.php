<?php include "../Config/App/Conn.php"?>  
<div class="p-3 row wrapper">
                <?php
                    $sql = "SELECT * FROM dinersTable";
                    $result = mysqli_query($conn, $sql);
                    $resultCheck = mysqli_num_rows($result);
                    
                    if ($resultCheck > 0) {
                        while($row = mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $active = $row['activeTable'];
                            if($active==1){
                                echo   '<div class="col"> 
                                            <button type="button" id="'.$id.'" class="btn btn-warning" style="width: 100%; height: 5rem;" onclick="orderForm('.$id.','.$active.')">
                                                <h1 class="text-white"><strong>'.$id.'</strong></h1>
                                            </button> 
                                        </div>';
                            }else {
                                echo    '<div class="col"> 
                                            <button type="button" id="'.$id.'" class="btn btn-light" style="width: 100%; height: 5rem;" onclick="orderForm('.$id.','.$active.')">
                                                <h1 class="text-black"><strong>'.$id.'</strong></h1>
                                            </button>
                                        </div>';
                            }
                        }
                    }
                ?>
</div>