<?php include "../Config/App/Conn.php";  

    if($_POST){
        $id = $_POST['tableId'];
        $numOfClients = $_POST['numOfClientsInput'];
        if ($numOfClients != "" && $id != "") {
            $sql = "CALL spUpdateTableClients($id,$numOfClients)";
            $result = mysqli_query($conn, $sql);
            echo json_encode($result);
        }else{
            echo json_encode('fill all data');
        }
    }
   
?>