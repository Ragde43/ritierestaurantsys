<?php include "../Config/App/Conn.php";

    $jsonString="";
    if($_COOKIE){
        $tableId = $_COOKIE['tableId'];
        $sql = "SELECT numOfClients.numOfClients FROM numOfClients INNER JOIN dinersTable 
                WHERE numOfClients.id = $tableId AND activeTable = TRUE AND dinersTable.id = numOfClients.id;";
        $result = mysqli_query($conn,$sql) or die (mysqli_error($conn));
        foreach ($result as $dinersTable):
            $jsonString .= $dinersTable['numOfClients'];
        endforeach;
        echo json_encode($jsonString);
    }

?>
