<?php include "../Config/App/Conn.php";  

    if($_COOKIE){
        $productName = $_COOKIE['productName'];
        $productQty = $_COOKIE['productQty'];
        $clientNum = $_COOKIE['clientNum'];
        $tableId = $_COOKIE['tableId'];
        $productTypeId = $_COOKIE['productTypeId'];
        if ($productName != "" && $productQty != "" && $clientNum != "" && $tableId != "" && $productTypeId != "") {
            $sql = "INSERT INTO provitionalOrderTable VALUES(0,'$productName','$productQty','$clientNum','$tableId','$productTypeId',TRUE);";
            $result = mysqli_query($conn, $sql);
            echo json_encode($result);
        }else{
            echo json_encode('fill all data');
        }
    }
   
?>