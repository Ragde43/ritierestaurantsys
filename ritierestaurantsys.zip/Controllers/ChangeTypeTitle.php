<?php include "../Config/App/Conn.php";

if($_COOKIE){
    $id = $_COOKIE['typeId'];
    $sql = "SELECT typeName FROM productTypes WHERE id = $id";
    $result = mysqli_query($conn,$sql) or die (mysqli_error($conn));
    foreach ($result as $productName):
            $jsonString = $productName['typeName'];
    endforeach;
    echo json_encode($jsonString);
}

?>