<?php include "../Config/App/Conn.php";  

    $tableId = $_COOKIE['tableId'];
    if ($tableId != "") {
        $sql = "CALL spPayTableClients($tableId)";
        $result = mysqli_query($conn, $sql);
        echo json_encode('success');
    }else{
        echo json_encode('fill all data');
    }

?>