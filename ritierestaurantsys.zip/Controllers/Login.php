<?php
session_start();
    if (!empty($_POST["loginBtn"])) {
        if (!empty($_POST["user"]) and !empty($_POST["password"])) {
            $user = $_POST["user"];
            $password = $_POST["password"];
            $hash = hash("SHA256", $password);
            $sql = $conn->query("SELECT * FROM users WHERE userName = '$user' AND pass = '$hash'");
            $datos = $sql->fetch_object();
            if($datos){
                $_SESSION["id"] = $datos->id;
                $_SESSION["userName"] = $datos->userName;
                // header("location: User/index.php");
                echo '<script>window.location="User/index.php"</script>';
            }else {
                echo "<div class='alert alert-danger'>Usuario y contraseña incorrectos</div>";
            }
        } else {
            echo "Es necesario rellenar todos los campos";
        }
        
    }

?>