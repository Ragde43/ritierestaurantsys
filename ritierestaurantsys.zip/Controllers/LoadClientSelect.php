<?php include "../Config/App/Conn.php";

    $jsonString = "";   
    if($_COOKIE){
        $id = $_COOKIE['tableId'];
        $sql = "SELECT numOfClients FROM numOfClients WHERE id = $id";
        $result = mysqli_query($conn,$sql) or die (mysqli_error($conn));
        foreach ($result as $numOfClients):
            for ($i=1; $i <= $numOfClients['numOfClients']; $i++) { 
                $jsonString .= '<option value="'.$i.'">'.$i.'</option> ';
            }
        endforeach;
        echo json_encode($jsonString);
    }

?>
