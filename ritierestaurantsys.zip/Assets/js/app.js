// $(document).ready(function(){
//     $(searchProducts());
//     $(searchProductTypes());
//     $(searchProviders());

//     function searchProducts(consult){
//         $.ajax({
//             url: 'product_search.php',
//             type: 'POST',
//             dataType: 'html',
//             data: {consult: consult}
//             })
//         .done(function(response){
//             $('#productsTable').html(response);
//         })
//     }
//     $(document).on('keyup','#search',function(){
//         var valor = $(this).val();
//         if(valor != ""){
//             searchProducts(valor);
//         }else{
//             searchProducts();
//         }
//     })



//     function searchProductTypes(consult){
//         $.ajax({
//             url: 'productType_search.php',
//             type: 'POST',
//             dataType: 'html',
//             data: {consult: consult}
//             })
//         .done(function(response){
//             $('#productTypesTable').html(response);
//         })
//     }
//     $(document).on('keyup','#search',function(){
//         var valor = $(this).val();
//         if(valor != ""){
//             searchProductTypes(valor);
//         }else{
//             searchProductTypes();
//         }
//     })



//     function searchProviders(consult){
//         $.ajax({
//             url: 'provider_search.php',
//             type: 'POST',
//             dataType: 'html',
//             data: {consult: consult}
//             })
//         .done(function(response){
//             $('#providersTable').html(response);
//         })
//     }
//     $(document).on('keyup','#search',function(){
//         var valor = $(this).val();
//         if(valor != ""){
//             searchProviders(valor);
//         }else{
//             searchProviders();
//         }
//     })

    
// });



