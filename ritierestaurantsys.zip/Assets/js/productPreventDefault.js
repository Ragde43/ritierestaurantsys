
// const productForm = document.getElementById("saveProductForm");
// productForm.addEventListener("submit", function(e){
//         e.preventDefault();   
//         let transactionFormData = new FormData(productForm);
//         transactionFormData.get("productKey");
//         transactionFormData.get("productName");
//         transactionFormData.get("productCost");
//         transactionFormData.get("price");
//         transactionFormData.get("stock");
//         transactionFormData.get("productType");
//         transactionFormData.get("provider");
//     }
// );
