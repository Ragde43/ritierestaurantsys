let tableUsers,tableClients,tableProducts,tableProductTypes;
let userName;
let actualDate = new Date();

let weekDay = ['Domingo, ', 'Lunes, ', 'Martes, ', 'Miércoles, ', 'Jueves, ', 'Viernes, ', 'Sábado, '];
let month = ['Enero de ', 'Febrero de ','Marzo de ','Abril de ','Mayo de ','Junio de ','Julio de ','Agosto de ','Septiembre de ','Octubre de ','Nobiembre de ','Diciembre de '];
let showDate = document.getElementById("date");
showDate.innerHTML = "<strong>"+`${weekDay[actualDate.getDay()]} ${actualDate.getDate()} de ${month[actualDate.getMonth()]} ${actualDate.getFullYear()}`+"</strong>";
