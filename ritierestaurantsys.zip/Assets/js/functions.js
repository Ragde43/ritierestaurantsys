var clientOrdersView = document.getElementById("clientOrdersView");
var clientSelect = document.getElementById("clientSelect");
var dessert = document.getElementById("lblDessert");
var drink = document.getElementById("lblDrink"); 
var entry = document.getElementById("lblEntry");
var mainDish = document.getElementById("lblMainDish");
var numOfClientsInput = document.getElementById("numOfClientsInput");
var numOfClientsForm =  document.getElementById("numOfClientsForm");
var orderResume = document.getElementById("orderResume");
var productSelector = document.getElementById("productSelector");
var productType = document.getElementById("typeBreadcrumb");
var productTypeSelect = document.getElementById("productTypeSelect");
var qty = document.getElementById("qtyInput");
var tableActiveForm = document.getElementById("tableActiveForm");
var tableId3;

function addClient(e) {
    e.preventDefault();
    Cookies.set("tableId",tableId.value);
    http = new XMLHttpRequest();
    url = 'http://localhost/restaurantSystem2/Controllers/GetClientsNum.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            const obj = JSON.parse(this.responseText);
            numOfClientsInput.value = obj;
        }
    }
    http.open("GET",url);
    http.send();
    $("#order").modal("hide");
    $("#numOfClients").modal("show");
}

function addDiner() {
    $("#order").modal("hide");
    $("#numOfClients").modal("show");
}

function addProduct(e){
    e.preventDefault();
    const productName = document.getElementById("productName");
    const productType = document.getElementById("productType");

    if(productName.value == "" || productType.value == ""){
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: 'Es necesario rellenar todos los campos del formulario.',
            showConfirmButton: false,
            timer: 2500
          })
    }else{
        const url = base_url + "/Products/addProduct";
        const form = document.getElementById("productForm");
        const http = new XMLHttpRequest();
        http.open("POST",url,true);
        http.send(new FormData(form));
        http.onreadystatechange = function(){
            if(this.readyState==4 && this.status == 200){
                console.log(this.responseText);
                const res = JSON.parse(this.responseText);
                if (res == "si") {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: 'Producto registrado con éxito.',
                        showConfirmButton: false,
                        timer: 2500
                      })
                      form.reset();
                    //   $("#newProduct").modal("hide");
                    //   tableProducts.ajax.reload();
                }else if(res == "modified"){
                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: 'Producto modificado con éxito.',
                        showConfirmButton: false,
                        timer: 2500
                      })
                      $("#newProduct").modal("hide");
                      tableProducts.ajax.reload();
                }else{
                    Swal.fire({
                        position: 'top-end',
                        icon: 'error',
                        title: res,
                        showConfirmButton: false,
                        timer: 2500
                      })
                }
            }
        }
    }
}

function addProductForm(){
    document.getElementById("myModalTitle").innerHTML = "Agregar producto";
    document.getElementById("modalActionBtn").innerHTML = "Agregar";
    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/FillProductType.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log("ya no se mira pasaaar");
            console.log(this.responseText);
            const obj = JSON.parse(this.responseText);
            console.log(obj);
            document.getElementById("productTypeSelect").innerHTML = obj;
        }
    }
    http.open("GET",url);
    http.send();
    $("#newProduct").modal("show");
}

function addTable(){
    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/AddTable.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            const obj = JSON.parse(this.responseText);
            console.log(obj);
        }
    }
    http.open("GET",url);
    http.send();
    setTimeout(() => {
        updateTables();
      }, 50);
}

function addToOrder() {
    
    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/LoadClientSelect.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            const obj = JSON.parse(this.responseText);
            console.log(obj);
            document.getElementById("clientSelect").innerHTML = obj;
        }
    }
    http.open("GET",url);
    http.send();
    
}

function addToProvitionalTable(e) {
    e.preventDefault();
    switch (productType.textContent) {
        case "BEBIDAS":
            if (drink.innerHTML=='') drink.innerHTML = (qty.value + " " + $("#productSelector option:selected").text());
            else drink.innerHTML += (qty.value + " " + $("#productSelector option:selected").text());
        break;
        case "ENTRADAS":
            if (entry.innerHTML=='') entry.innerHTML = (qty.value + " " + $("#productSelector option:selected").text());
            else entry.innerHTML += (qty.value + " " + $("#productSelector option:selected").text());
        break;
        case "PLATILLOS":
            if (mainDish.innerHTML=='') mainDish.innerHTML = (qty.value + " " + $("#productSelector option:selected").text());
            else mainDish.innerHTML += (qty.value + " " + $("#productSelector option:selected").text());
        break;
        case "POSTRES":
            if (dessert.innerHTML=='') dessert.innerHTML = (qty.value + " " + $("#productSelector option:selected").text());
            else dessert.innerHTML += (qty.value + " " + $("#productSelector option:selected").text());
        break;
        default:
            break;
    }
    var productName = $( "#productSelector option:selected" ).text();
    Cookies.set("productName",productName);
    Cookies.set("productQty",qty.value);
    Cookies.set("clientNum",clientSelect.value);
    Cookies.set("tableId",tableId.value);
    Cookies.set("productTypeId",productSelector.value);

    var http = new XMLHttpRequest();
    var url = 'http://localhost/restaurantSystem2/Controllers/AddToProvitional.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            const obj = JSON.parse(this.responseText);

        }
    }
    http.open("GET",url);
    http.send();
    qty.value = 1;
}

function decrementValue(e) {
    e.preventDefault();
    var fieldName = $(e.target).data('field');
    var parent = $(e.target).closest('div');
    var currentVal = parseInt(parent.find('input[name=' + fieldName + ']').val(), 10);
  
    if (!isNaN(currentVal) && currentVal > 0) {
      parent.find('input[name=' + fieldName + ']').val(currentVal - 1);
    } else {
      parent.find('input[name=' + fieldName + ']').val(0);
    }
}

function fillClientNumOrder(clientNum) {
    Cookies.set("clientNum",clientNum);
    Cookies.set("tableId",tableId.value);
    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/FillClientNumOrder.php';

    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            $string = this.responseText;
             const obj = JSON.parse(this.responseText);
             console.log(obj);
             console.log(obj['productType']);
             var id;
             for (let i = 0; i < obj['productType'].length; i++) {
                id = obj['productType'][i];
                console.log(obj['productType'][i] + " " + obj['qty'][i] + " " +obj['productName'][i]);
                if (id == 1) {
                    drink.innerHTML += obj['qty'][i] + " " + obj['productName'][i] + "<br>";
                }else if (id == 2) {
                    entry.innerHTML += obj['qty'][i] + " " + obj['productName'][i] + "<br>";
                }else if (id == 3) {
                    mainDish.innerHTML += obj['qty'][i] + " " + obj['productName'][i] + "<br>";
                }else if (id == 4) {
                    dessert.innerHTML += obj['qty'][i] + " " + obj['productName'][i] + "<br>";
                }
             }
        }
    }
    http.open("GET",url);
    http.send();
}

function getStarted() {
    window.location = "http://localhost/restaurantSystem2/Views/Tables/index.php";
}

function incrementValue(e) {
    e.preventDefault();
    var fieldName = $(e.target).data('field');
    var parent = $(e.target).closest('div');
    var currentVal = parseInt(parent.find('input[name=' + fieldName + ']').val(), 10);
  
    if (!isNaN(currentVal)) {
      parent.find('input[name=' + fieldName + ']').val(currentVal + 1);
    } else {
      parent.find('input[name=' + fieldName + ']').val(0);
    }
}

function loadClientSelect(){
    Cookies.set("tableId",tableId.value);

    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/LoadClientSelect.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            const obj = JSON.parse(this.responseText);
            console.log(obj);
            clientSelect.innerHTML = obj;
        }
    }
    http.open("GET",url);
    http.send();
   
}

function login() {
    e.preventDefault;
    var user, pass;
    user = document.getElementById("user").value;
    pass = document.getElementById("password").value;
}

function loginForm(e){
    e.preventDefault();
    const user = document.getElementById("user");
    const pass = document.getElementById("password");
    var welcomeText = document.getElementById("welcomeText");
    if(user.value == ""){
        pass.classList.remove("is-invalid")
        user.classList.add("is-invalid");
        user.focus();
    }else if (pass.value == ""){
        user.classList.remove("is-invalid");
        pass.classList.add("is-invalid");
        pass.focus();
    }else{
        const url = base_url + "Users/validate";
        const form = document.getElementById("loginForm");
        const http = new XMLHttpRequest();
        http.open("POST",url,true);
        http.send(new FormData(form));
        http.onreadystatechange = function(){
            if(this.readyState==4 && this.status == 200){
                console.log(this.responseText);
                const res = JSON.parse(this.responseText);
                if(res == "Session ok."){

                    window.location = "http://localhost/restaurantSystem/";
                }else{
                    document.getElementById("alert").classList.remove("d-none");
                    document.getElementById("alert").innerHTML = res;
                }
            }
        }
    }
}

function orderForm(id,active){
    setTypeView(1);
    drink.innerHTML = "";
    entry.innerHTML = "";
    mainDish.innerHTML = "";
    dessert.innerHTML = "";
    var tableId = document.getElementById("tableId").value = id;
    var tableId2 = document.getElementById("tableId2").value = id;
    var tableIdHidden = document.getElementById("id").value = id;
    if(active==0){
        tableId = document.getElementById("tableId").value = id;
        tableId2 = document.getElementById("tableId2").value = id;
        document.getElementById("myModalTitleNumOfClients").innerHTML = "¿Cuántos clientes hay en la mesa?";
        $("#numOfClients").modal("show");
        document.getElementById("myModalTitle").innerHTML = "Orden de mesa " + tableId2;
    }else{
        fillClientNumOrder(1);
        tableId = document.getElementById("tableId").value = id;
        tableId2 = document.getElementById("tableId2").value = id;
        loadClientSelect();
        $("#numOfClients").modal("hide");
        document.getElementById("id").value = "";
        document.getElementById("myModalTitle").innerHTML = "Orden de mesa " + tableId2;
        document.getElementById("modalActionBtn").innerHTML = "Agregar";
        // document.getElementById("tableActiveForm").reset();
        $("#order").modal("show");
    }
}

function orderFormCashierView(tableId){
    tableId3 = tableId;
    document.getElementById("orderModalTitle").innerHTML = "Orden de mesa " + tableId;
    clientOrdersView.innerHTML = "";
    console.log(tableId);
    Cookies.set("tableId",tableId);

    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/FillOrdersModal.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            const obj = JSON.parse(this.responseText);
            console.log(obj);
            obj['clientNum'] = obj['clientNum'].reduce((a,e)=> {
                if(!a.find(d => d == e)){
                    a.push(e);
                }
                return a;
            },[]);
            obj['productType'] = obj['productType'].reduce((a,e)=> {
                if(!a.find(d => d == e)){
                    a.push(e);
                }
                return a;
            },[]);
            console.log("lblMainDish"+obj['clientNum'][1]);
            var id;
            for (let i = 0; i < obj['clientNum'].length; i++) {
                clientOrdersView.innerHTML += `<div class="col text-center" style="width: 30%">
                                                    <div id="clientNumView">
                                                        <h1><i class="fa-regular fa-user"></i></h1>
                                                        <h3><strong>Cliente</strong></h3>
                                                        <label for=""><strong>`+(i+1)+`</strong></label>
                                                    </div>
                                                    <div id="orderResume" class="mt-3 text-align-left">
                                                        <strong>Bebida</strong><br>
                                                        <label id="lblDrink`+(i+1)+`" for=""></label><br>
                                                        <strong>Entrada</strong><br>
                                                        <label id="lblEntry`+(i+1)+`" for=""></label><br>
                                                        <strong>Plato principal</strong><br>
                                                        <label id="lblMainDish`+(i+1)+`" for=""></label><br>
                                                        <strong>Postre</strong><br>
                                                        <label id="lblDessert`+(i+1)+`" for=""></label><br>
                                                    </div>
                                                </div>`;
                
            }
            //lblDrink, lblEntry, lblMainDish, lblDessert
            var k = 0;
            for (let i = 0; i < obj['clientNum'].length; i++) {
                dessert = document.getElementById("lblDessert"+obj['clientNum'][i]);
                drink = document.getElementById("lblDrink"+obj['clientNum'][i]); 
                entry = document.getElementById("lblEntry"+obj['clientNum'][i]);
                mainDish = document.getElementById("lblMainDish"+obj['clientNum'][i]);
                for (let j = 0; j < obj['productType'].length; j++) {
                    id = obj['productType'][j];
                    if (id == 1) {
                        drink.innerHTML += obj['qty'][k] + " " + obj['productName'][k] + "<br>";
                    }else if (id == 2) {
                        entry.innerHTML += obj['qty'][k] + " " + obj['productName'][k] + "<br>";
                    }else if (id == 3) {
                        mainDish.innerHTML += obj['qty'][k] + " " + obj['productName'][k] + "<br>";
                    }else if (id == 4) {
                        dessert.innerHTML += obj['qty'][k] + " " + obj['productName'][k] + "<br>";
                    }
                    k+=1;
                }
             }
        }
    }
    http.open("GET",url);
    http.send();
    $("#order").modal("show");
}

function payAccount() {
    Cookies.set("tag","payAcc");
    Cookies.set("tableId", tableId3);
    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/Account.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            const obj = JSON.parse(this.responseText);
            console.log(obj);
        }
    }
    http.open("GET",url);
    http.send();
    setTimeout(() => {
        updateOrderTables();
        $("#order").modal("hide");
      }, 50);
}

function setTypeView(id) {
    Cookies.set("typeId",id);
    var http = new XMLHttpRequest();
    var url = 'http://localhost/restaurantSystem2/Controllers/ChangeTypeTitle.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            const obj = JSON.parse(this.responseText);
            document.getElementById("typeBreadcrumb").innerHTML = obj;
        }
    }
    http.open("GET",url);
    http.send();

    http = new XMLHttpRequest();
    url = 'http://localhost/restaurantSystem2/Controllers/LoadProductTypes.php';
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            const obj = JSON.parse(this.responseText);
            productSelector.innerHTML = obj;
        }
    }
    http.open("GET",url);
    http.send();
}

function updateTables(){
    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/LoadTables.php';

    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("table_status").innerHTML = this.responseText;
        }
    }
    http.open("GET",url);
    http.send();
    
}

function updateOrderTables(){
    const http = new XMLHttpRequest();
    const url = 'http://localhost/restaurantSystem2/Controllers/ActiveTableOrders.php';

    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("table_status").innerHTML = this.responseText;
        }
    }
    http.open("GET",url);
    http.send();
    
}
  

numOfClientsForm.addEventListener('submit',function(e) {
    e.preventDefault();
    var data = new FormData(numOfClientsForm);
    setTimeout(() => {
        loadClientSelect();
      }, 50); 
    
    fetch('http://localhost/restaurantSystem2/Controllers/Tables.php',{
        method: 'POST',
        body: data
    })
    .then(res => res.json())
    .then(data =>{
        console.log(data);
    });
    setTimeout(() => {
        updateTables();
        $("#numOfClients").modal("hide");
        $("#order").modal("show");
      }, 50);
    
})


$('#clientSelect').change(function(){ 
    drink.innerHTML = "";
    entry.innerHTML = "";
    mainDish.innerHTML = "";
    dessert.innerHTML = "";
    setTimeout(() => {
        fillClientNumOrder(clientSelect.value);
    }, 50); 
});

$('.input-group').on('click', '.button-plus', function(e) {
    incrementValue(e);
});
  
$('.input-group').on('click', '.button-minus', function(e) {
    decrementValue(e);
});
  
document.addEventListener("DOMContentLoaded", function(){
    tableUsers = $('#tableUsers').DataTable( {
        ajax: {
            url: "http://localhost/backhoe/Users/listUsers",
            dataSrc: ''
        },
        columns: [ 
            {'data' : 'id'},
            {'data' : 'officeName'},
            {'data' : 'manager'},
            {'data' : 'userName'},
            {'data' : 'roleName'},
            {'data' : 'actions'}
        ]
    } );

    tableProducts = $('#tableProducts').DataTable( {
        ajax: {
            url: "http://localhost/backhoe/Products/listProducts",
            dataSrc: ''
        },
        columns: [ 
            {'data' : 'productKey'},
            {'data' : 'productName'},
            {'data' : 'productCost'},
            {'data' : 'price'},
            {'data' : 'stock'},
            {'data' : 'typeName'},
            {'data' : 'actions'}
        ]
        
    } );
    
})