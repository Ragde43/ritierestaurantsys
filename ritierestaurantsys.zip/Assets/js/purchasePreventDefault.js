// let getData = document.getElementsByTagName("td");
// let purchaseForm = document.getElementById("savePurchaseForm");
// let transactionFormData;
// let getRow;
// let rowData;
// // const productNameIn = document.getElementById("productNameIn");
// let tdCount = 2;
// purchaseForm.addEventListener("submit", function(e){
//     e.preventDefault();   
//     transactionFormData = new FormData(purchaseForm);
//     let transactionTableRef = document.getElementById("transactionTable");   
    
//     if(transactionFormData.get("productName")!="" && transactionFormData.get("productAmount")!="" && transactionFormData.get("productCost")!=""){    
//         tdCount+=3;
//         console.log(tdCount);
//         let newTransactionRowRef = transactionTableRef.insertRow(-1);
//         newTransactionRowRef.id = "row" + tdCount + "";
//         getRow = document.getElementById("row"+tdCount+"");
//         rowData = getRow.getElementsByTagName("td");
        
//         let newProductCellRef = newTransactionRowRef.insertCell(0);
//         newProductCellRef.textContent = transactionFormData.get("productName");
//         newProductCellRef = newTransactionRowRef.insertCell(1);
//         newProductCellRef.textContent = transactionFormData.get("productAmount");
//         newProductCellRef = newTransactionRowRef.insertCell(2);
//         newProductCellRef.textContent = transactionFormData.get("productCost");
//         for(let x=0; x<rowData.length;x++){
//             console.log(rowData[x].innerHTML);
//         }
//         document.getElementById("productNameIn").value = "";
//         productNameIn.focus();
//     }

//     }
// );



// let savePurchaseButton = document.getElementById("savePurchaseButton");
// savePurchaseButton.addEventListener("click", function(e){
//     let saveCount = 5;
//     var product;
//     while(saveCount<=tdCount){
//         getRow = document.getElementById("row"+saveCount+"");
//         rowData = getRow.getElementsByTagName("td");
//         product = rowData[0].innerHTML;
//         cost = rowData[1].innerHTML;
//         amount = rowData[2].innerHTML;
//         // var data = $(this).serializeArray();
//         // data.push({name: 'productName',value: product})
//         // $.ajax({
//         //     url: 'save_purchase.php',
//         //     type: "post",
//         //     dataType: 'json',
//         //     data: data
//         // });
//         $.post('save_purchase.php',{productName:product,productCost:cost,productAmount:amount,productCount: tdCount}, function(data){
            
//             if(data!=null){
//                 console.log("El botón guardar ha sido presionado.");
//             }else{
//                 alert("La NO entrada se ha creado correctamente.")
//             }
//         })
//         getRow.remove();
//         saveCount+=3;
//     }
//     tdCount = 2;
// });

